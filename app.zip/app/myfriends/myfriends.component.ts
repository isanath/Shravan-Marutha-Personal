import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookService } from '../services/capbook.service';
import { Route } from '@angular/compiler/src/core';
import { Person } from '../signup/Person';

@Component({
  selector: 'app-myfriends',
  templateUrl: './myfriends.component.html',
  styleUrls: ['./myfriends.component.css']
})
export class MyfriendsComponent implements OnInit {
   emailId:string
   friends:Person[]
   errorMessage:string
  constructor(private route:ActivatedRoute,private capbookService:CapbookService,private router:Router) { }

  ngOnInit() {
    if(!localStorage.getItem('user'))
    this.router.navigate(['home']);
    this.emailId= JSON.parse(localStorage.getItem('user'));
    this.capbookService.getAllFriends(this.emailId).subscribe(
      tempFriends =>{
      this.friends=tempFriends;
      }, errorMessage=>{
        this.errorMessage = errorMessage;}
    )
  }

}
