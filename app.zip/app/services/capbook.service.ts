import { Injectable } from '@angular/core';
import { Person } from '../signup/Person';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {map, catchError } from 'rxjs/operators'
import { Message } from '../signup/Message';
import { Post } from '../myProfile/Post';
import { Notif } from '../notif';

@Injectable({
  providedIn: 'root'
})
export class CapbookService {
  
  constructor(private httpClient:HttpClient) { }
  public acceptUserDetails(user:Person):Observable<Person>{
    console.log(user);
    return this.httpClient.post<Person>("http://10.220.56.77:1997/signUp",JSON.parse(JSON.stringify(user))).pipe(catchError(this.handleError));
  }
  public checkLoginDetails(emailId:string,password:string):Observable<Person>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      params=params.set('password',password.toString());
    return this.httpClient.get<Person>("http://10.220.56.77:1997/login",{params:params}).pipe(catchError(this.handleError));
  }
  public getUserDetails(emailId:string):Observable<Person>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
     
    return this.httpClient.get<Person>("http://10.220.56.77:1997/getUserDetails",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllUsersDetails(emailId:string): Observable<Person[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
    return this.httpClient.get<Person[]>("http://10.220.56.77:1997/findNewFriends",{params:params}).pipe(catchError(this.handleError));
  }
  public sendFriendRequest(requesterEmailId:string,friendEmailId:string):Observable<any>{
    let params=new HttpParams();
      params=params.set('requesterEmailId',requesterEmailId.toString());
      params=params.set('friendEmailId',friendEmailId.toString());
      console.log(requesterEmailId,friendEmailId)
    return this.httpClient.get<any>("http://10.220.56.77:1997/friendRequest",{params:params}).pipe(catchError(this.handleError));
  }

  public acceptFriendRequest(approverEmailId:string,friendEmailId:string):Observable<Message>{
    let params=new HttpParams();
      params=params.set('approverEmailId',approverEmailId.toString());
      params=params.set('friendEmailId',friendEmailId.toString());
    return this.httpClient.get<Message>("http://10.220.56.77:1997/acceptFriendRequest",{params:params}).pipe(catchError(this.handleError));
  }
  public sendPostDetails(emailId:string,message:string):Observable<any>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      params=params.set('message',message.toString());
    return this.httpClient.get<any>("http://10.220.56.77:1997/sendPost",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllPosts(emailId:string):Observable<Post[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      
    return this.httpClient.get<Post[]>("http://10.220.56.77:1997/getAllPosts",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllNotifications(emailId:string):Observable<Notif[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      
    return this.httpClient.get<Notif[]>("http://10.220.56.77:1997/getNotifications",{params:params}).pipe(catchError(this.handleError));
  }
  public rejectFriendRequest(approverEmailId:string,friendEmailId:string):Observable<Message>{
    let params=new HttpParams();
      params=params.set('rejecterEmailId',approverEmailId.toString());
      params=params.set('friendEmailId',friendEmailId.toString());
    return this.httpClient.get<Message>("http://10.220.56.77:1997/deleteFriendRequest",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllFriends(emailId:string):Observable<Person[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      return this.httpClient.get<Person[]>("http://10.220.56.77:1997/findFriends",{params:params}).pipe(catchError(this.handleError));
  }
  
  public getFriendRequests(emailId:string):Observable<Person[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      return this.httpClient.get<Person[]>("http://10.220.56.77:1997/findFriendRequests",{params:params}).pipe(catchError(this.handleError));
  }
private handleError(error:any){
  if(error instanceof ErrorEvent){
    console.error(`1 An ErrorEvent occurred:`,error.error.message);

    return throwError(error.error.message);
  } else if(error instanceof HttpErrorResponse){
    console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
    return throwError(`Backend returned code ${error.status}, body was: ${error.message}`); 
  }  else if(error instanceof TypeError){
    console.error(`3 TypeError has occurred ${error.message}, body was ${error.stack} `);
    return throwError(`TypeError has occurred ${error.message}, body was ${error.stack} `);
  }
}
}
