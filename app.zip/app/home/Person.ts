export interface Person {
    emailId:string,
    firstName:string,
    lastName:string,
    phoneNo:number,
    dateOfBirth:string,
    gender:string,
    password:string;

    
}