import { Component, OnInit } from '@angular/core';
import { CapbookService } from '../services/capbook.service';
import { Person } from './Person';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public pageTitle:string="SignUp Form"
  public user:Person;
  public message:string;
  constructor(private capBookService:CapbookService) { }

  ngOnInit() {
   
  }
  onSubmit(user:Person){
    
    this.capBookService.acceptUserDetails(user).subscribe(
      user =>{
        this.user=user;
        if(user)
        this.message='Welcome to CapBook Family!!!';
        else
        this.message='User Already Exists!!!'
        this.ngOnInit();
        window.location.reload(); 
      }
       
    );

    }
}
