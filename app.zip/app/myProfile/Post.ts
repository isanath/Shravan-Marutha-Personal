

export interface Post{
    emailId:string;
    message:string;
    firstName:string;
    time:Date;
}