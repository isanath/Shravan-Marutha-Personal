import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Person } from '../signup/Person';
import { Message } from '../signup/Message';
import { CapbookService } from '../services/capbook.service';
import { Post } from './Post';
import { NgForOf } from '@angular/common';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

 
  emailId:string

  message:Message;
  _statusAssign:string;
  post:string;
  myDetails:Person;
  posterDetails:Person;
  firstName:string;
  lastName:string;
  _friendRequests:Person[];
  posts:Post[]
  constructor(private route:ActivatedRoute,private capbookService:CapbookService,private router:Router) { }

  ngOnInit() {
    if(!localStorage.getItem('user'))
    this.router.navigate(['/home']);
      this.emailId= JSON.parse(localStorage.getItem('user'));
      this.capbookService.getUserDetails(this.emailId).subscribe(
         tempfriends =>{
           this.myDetails=tempfriends;
           this.firstName=this.myDetails.firstName;
           this.lastName=this.myDetails.lastName;      
         }
      );
      this.capbookService.getFriendRequests(this.emailId).subscribe(
        tempfriends =>{
          this._friendRequests=tempfriends;
  
        }
  
      )
      this.capbookService.getAllPosts(this.emailId).subscribe(
        tempfriends =>{
          this.posts=tempfriends;
          this.posts.forEach(post => {
            this.capbookService.getUserDetails(post.emailId).subscribe(
              tempfriends =>{
                this.posterDetails=tempfriends;
                post.firstName=this.posterDetails.firstName;

              }
            )
            
          });

        }
      )
    
  }
  acceptFriendRequest(emailId:string):void{
    this.capbookService.acceptFriendRequest(this.emailId,emailId).subscribe(
      tempFriends=>{
               this.message=tempFriends
               window.location.reload();
      }
    )
    
  }
  rejectFriendRequest(emailId:string):void{
    this.capbookService.rejectFriendRequest(this.emailId,emailId).subscribe(
      tempFriends=>{
               this.message=tempFriends
               window.location.reload();
      }
    ) 
  }
  statusAssign(status:string):void{
    this._statusAssign=status;
    this.capbookService.sendPostDetails(this.emailId,this._statusAssign).subscribe();
    window.location.reload();
    
    
     this.post=this.emailId+'  updated status'
     
     
  }
 
}
