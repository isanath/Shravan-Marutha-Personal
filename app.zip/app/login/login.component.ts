import { Component, OnInit } from '@angular/core';
import { CapbookService } from '../services/capbook.service';
import { Router, ActivatedRoute } from '@angular/router';
import { stringify } from '@angular/core/src/util';
import { Person } from '../signup/Person';
import { nextContext } from '@angular/core/src/render3';
import { LocalStorageService } from 'ngx-webstorage';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(private route:ActivatedRoute,private capbookService:CapbookService,private router:Router) { }
  user:Person;
  _emailId:string;
  _password:string;
  errorMessage:string;

  get emailId():string{
    return this._emailId;
  }
  set emailId(value: string){
    this._emailId=value;
  }
  get password():string{
    return this._password;
  }
  set password(value: string){
    this._password=value;
  }
  message:string;
  ngOnInit() {
    if(localStorage.getItem('user'))
    this.router.navigate(['myProfile'])
  }
  onSubmit(){
  
    this.capbookService.checkLoginDetails(this._emailId,this._password).subscribe(
     person=>{
       this.user=person;
       if(person){
        localStorage.setItem('user', JSON.stringify(person.emailId));
        window.location.reload();
       }
       else
       this.message='Invalid credentials'
     },
     errorMessage=>{
      this.errorMessage = errorMessage;
    });
  
    

    
  }
  
    
}
