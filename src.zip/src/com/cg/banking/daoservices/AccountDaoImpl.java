package com.cg.banking.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.banking.beans.*;
import com.cg.banking.util.ConnectionProvider;
public class AccountDaoImpl implements AccountDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	@Override
	public Account saveAccountDetails(Account account) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("insert into account(accountNo,pinNumber,accountBalance,accountType,status) values(seq_accountNo.nextval,?,?,?,?)");
			pstmt1.setInt(1, account.getPinNumber());
			pstmt1.setFloat(2, account.getAccountBalance());
			pstmt1.setString(3, account.getAccountType());
			pstmt1.setString(4, account.getStatus());
			pstmt1.executeUpdate();
			PreparedStatement pstmt2=conn.prepareStatement("select max(accountNo) from account");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			long accountNo=rs.getLong(1);
			conn.commit();
			account.setAccountNo(accountNo);
			return account;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}
	@Override
	public Account getAccountDetails(long accountNo)  throws SQLException{
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("select * from account where accountNo="+accountNo);
			ResultSet accountrs = pstmt1.executeQuery();
			if(accountrs.next()){
				int pinNumber=accountrs.getInt("pinNumber");
				float accountBalance=accountrs.getFloat("accountBalance");
				String accountType=accountrs.getString("accountType");
				String status=accountrs.getString("status");
				Account account=new Account(pinNumber, accountType, status, accountBalance, accountNo);
				conn.commit();
				return account;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public ArrayList<Transaction> getAccountAllTransactionDetails(long accountNumber) {
		ArrayList<Transaction> transactions=new ArrayList<>();
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("select * from transaction where accountNo="+accountNumber);
			ResultSet transactionrs=pstmt1.executeQuery();
			while(transactionrs.next()){
				int transactionId=transactionrs.getInt("transactionId");
				float amount=transactionrs.getFloat("amount");
				String transactionType=transactionrs.getString("transactionType");
				Transaction transaction=new Transaction(transactionId, amount, transactionType);
				conn.commit();
				transactions.add(transaction);
			}
			return transactions;
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return null;
	}
	@Override
	public ArrayList<Account> getAllAccountDetails(){
		try {
			conn.setAutoCommit(false);
			ArrayList<Account> accounts=new ArrayList<>();
			PreparedStatement pstmt1=conn.prepareStatement("select * from account");
			ResultSet accountrs=pstmt1.executeQuery();
			while(accountrs.next()){
				long accountNo=accountrs.getLong("accountNo");
				int pinNumber=accountrs.getInt("pinNumber");
				float accountBalance=accountrs.getFloat("accountBalance");
				String accountType=accountrs.getString("accountType");
				String status=accountrs.getString("status");
				Account account=new Account(pinNumber, accountType, status, accountBalance, accountNo);
				conn.commit();
				accounts.add(account);
			}
			return accounts;
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return null;
	}
	@Override
	public String getAccountStatus(long accountNo){
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("select status from account where accountNo="+accountNo);
			ResultSet rs=pstmt1.executeQuery();
			rs.next();
			String status= rs.getString("status");
			conn.commit();
			return status;
		}catch (SQLException e) {
			e.printStackTrace();
		}	
		return null;
	}
	@Override
	public int updateTransaction(long accountNo,float amount,String transactionType) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("insert into transaction(transactionId,accountNo,amount,transactionType) values(seq_transactionId.nextval,?,?,?)");
			pstmt1.setLong(1, accountNo);
			pstmt1.setFloat(2, amount);
			pstmt1.setString(3, transactionType);
			pstmt1.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
		return 0;
	}
	@Override
	public boolean updateAccount(Account account) throws SQLException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("Update account set accountBalance = ? where accountNo="+account.getAccountNo());
			pstmt1.setFloat(1, account.getAccountBalance());
			int flag=pstmt1.executeUpdate();
			conn.commit();
			if (flag > 0)	return true;
			else	return false;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}
}