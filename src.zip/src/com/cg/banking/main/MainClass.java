package com.cg.banking.main;
import com.cg.banking.exceptions.*;
import com.cg.banking.services.*;
public class MainClass {
	public static void main(String[] args) throws InvalidAmountException,InvalidAccountTypeException,AccountNotFoundException,AccountBlockedException,InvalidPinNumberException,InsufficientAmountException{
		BankingServices services=new BankingServicesImpl();
		try {
			
			
			long accountNo=services.openAccount("Savings", 15000,1234,"Active");
			System.out.println(accountNo);
			
			long accountNo1=services.openAccount("Current", 5000, 2345, "Active");
			System.out.println(accountNo1);
			
			
			services.openAccount("Salary", 10000,3465,"Active");
			
			float accountBalance=services.depositAmount(111114, 2000);
			System.out.println(accountBalance);
			
			
			
			services.withdrawAmount(111114, 1000, 1234);
		
			
			
			services.fundTransfer(111112, 111111, 1000, 1234);
			
			
			/*
			System.out.println(services.accountStatus(111114));
			System.out.println(services.getAccountAllTransaction(111114).toString());
			 */

		} catch (BankingServicesDownException e) {
			e.printStackTrace();
		}
	}
}