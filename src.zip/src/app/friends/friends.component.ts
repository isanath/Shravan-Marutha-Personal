import { Component, OnInit } from '@angular/core';
import { CapbookService } from '../services/capbook.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Person } from '../signup/Person';
import { Message } from '../signup/Message';

@Component({
  selector: 'app-friends',
  templateUrl: './friends.component.html',
  styleUrls: ['./friends.component.css']
})
export class FriendsComponent implements OnInit {
  _listFilter:string;
  friendsList:Person[];
  friends:Person[];
  error:string;
  message:Message;
  success:string;
  emailId:string;
 
  
  constructor(private capbookService:CapbookService, private router:Router,private route:ActivatedRoute){
    this._listFilter=""
    
    
  }
  get listFilter(): string{
    return this._listFilter;
  }
  set listFilter(value: string){
    this._listFilter=value;
    this.friendsList=this.friendsList?this.doFriendsFilter(this._listFilter):this.friends
  }
  doFriendsFilter(filterBy: string): Person[]{
    filterBy=filterBy.toLowerCase();
    return this.friends.filter(person=> person.emailId.toLowerCase().indexOf(filterBy)!==-1);
  }
 
  ngOnInit() {
    var id = this.route.snapshot.paramMap.get('id');
      this.emailId= id;
    this.capbookService.getAllUsersDetails(this.emailId).subscribe(
      tempFriends=>{
        this.friends=tempFriends;
        this.friendsList=this.friends;
      }
      ,
      error=>{
       this.error=error;
      }

    );
  }
  public navigateBack(): void{
this.router.navigate(['/welcome']);
  }
   
  addFriend(emailId:string): void{
    this.capbookService.sendFriendRequest(this.emailId,emailId).subscribe(
      tempFriends=>{
        this.message=tempFriends
        this.success=this.message.message.toString()
        console.log(this.message)
        this.router.navigate(['redirect:/friends:emailId'])
      }
      ,
      error=>{
       this.error=error;
      }

    );
    

  }
  doFriendsFiltering(filterBy:string): Person[]{
    filterBy=filterBy.toLowerCase();
    return this.friends.filter(person =>
      person.emailId.toLowerCase().indexOf(filterBy)!==-1);
  }
}
