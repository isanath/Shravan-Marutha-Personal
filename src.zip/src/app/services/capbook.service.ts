import { Injectable } from '@angular/core';
import { Person } from '../signup/Person';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {map, catchError } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class CapbookService {
 
  constructor(private httpClient:HttpClient) { }
  public acceptUserDetails(user:Person):Observable<Person>{
    console.log(user);
    return this.httpClient.post<Person>("http://10.220.56.77:1998/SignUp",JSON.parse(JSON.stringify(user))).pipe(catchError(this.handleError));
  }

private handleError(error:any){
  if(error instanceof ErrorEvent){
    console.error(`1 An ErrorEvent occurred:`,error.error.message);
    return throwError(error.error.message);
  } else if(error instanceof HttpErrorResponse){
    console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
    return throwError(`Backend returned code ${error.status}, body was: ${error.message}`); 
  }  else if(error instanceof TypeError){
    console.error(`3 TypeError has occurred ${error.message}, body was ${error.stack} `);
    return throwError(`TypeError has occurred ${error.message}, body was ${error.stack} `);
  }
}
}
