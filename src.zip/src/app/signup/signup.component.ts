import { Component, OnInit } from '@angular/core';
import { Person } from './Person';
import { CapbookService } from '../services/capbook.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public pageTitle:string="SignUp Form"
  public user:Person;
  constructor(private capBookService:CapbookService) { }

  ngOnInit() {
  }
  onSubmit(user:Person){
    this.capBookService.acceptUserDetails(user).subscribe(
      user =>{
        this.user=user;
        
      }
  
    );

    }}
