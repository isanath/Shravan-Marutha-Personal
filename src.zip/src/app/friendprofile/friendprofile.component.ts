import { Component, OnInit } from '@angular/core';
import { CapbookService } from '../services/capbook.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Person } from '../signup/Person';

@Component({
  selector: 'app-friendprofile',
  templateUrl: './friendprofile.component.html',
  styleUrls: ['./friendprofile.component.css']
})
export class FriendprofileComponent implements OnInit {

  emailId:string
  fEmailId:string 
  friend:Person
  constructor(private capbookService:CapbookService, private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
      var id1 = this.route.snapshot.paramMap.get('id1');
      this.fEmailId= id1;

      this.capbookService.getUserDetails(this.fEmailId).subscribe(
        tempfriends=>{
          this.friend=tempfriends;
          console.log(this.friend);

        }
      )
       
    }




}
