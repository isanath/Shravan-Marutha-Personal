import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookService } from '../services/capbook.service';
import { Route } from '@angular/compiler/src/core';
import { Person } from '../signup/Person';

@Component({
  selector: 'app-myfriends',
  templateUrl: './myfriends.component.html',
  styleUrls: ['./myfriends.component.css']
})
export class MyfriendsComponent implements OnInit {
   emailId:string
   friends:Person[]
   errorMessage:string
  constructor(private route:ActivatedRoute,private capbookService:CapbookService,private router:Router) { }

  ngOnInit() {
    var id = this.route.snapshot.paramMap.get('id');
    this.emailId= id;
    this.capbookService.getAllFriends(this.emailId).subscribe(
      tempFriends =>{
      this.friends=tempFriends;
      }, errorMessage=>{
        this.errorMessage = errorMessage;}
    )
  }

}
