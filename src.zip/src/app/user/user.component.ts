import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Person } from '../signup/Person';
import { CapbookService } from '../services/capbook.service';
import { Message } from '../signup/Message';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  emailId:string
  _friendRequests:Person[];
  message:Message;
  _statusAssign:string;
  post:string;
  myDetails:Person;
  firstName:string;
  lastName:string;
  
  constructor(private route:ActivatedRoute,private capbookService:CapbookService,private router:Router) { }

  ngOnInit() {
    var id = this.route.snapshot.paramMap.get('id');
      this.emailId= id;
      this.capbookService.getUserDetails(this.emailId).subscribe(
         tempfriends =>{
           this.myDetails=tempfriends;
           this.firstName=this.myDetails.firstName;
           this.lastName=this.myDetails.lastName;
           
         }
      )
      
  }
  friendRequests(){
    this.capbookService.getFriendRequests(this.emailId).subscribe(
      tempfriends =>{
        this._friendRequests=tempfriends;

      }

    )
    

  }
  
  statusAssign(status:string):void{
    this._statusAssign=status;
    status=' '
     this.post=this.emailId+'  updated status'
     
  }
  acceptFriendRequest(emailId:string):void{
    this.capbookService.acceptFriendRequest(this.emailId,emailId).subscribe(
      tempFriends=>{
               this.message=tempFriends
      }
    )
  }
  rejectFriendRequest(emailId:string):void{
    this.capbookService.rejectFriendRequest(this.emailId,emailId).subscribe(
      tempFriends=>{
               this.message=tempFriends
      }
    )
  }

}
