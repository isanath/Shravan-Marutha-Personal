import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { CapbookService } from './services/capbook.service';
import { HttpClientModule } from '@angular/common/http';
import { UserComponent } from './user/user.component';
import { FriendsComponent } from './friends/friends.component';
import { MyfriendsComponent } from './myfriends/myfriends.component';
import { FriendprofileComponent } from './friendprofile/friendprofile.component';
import{NgxWebstorageModule, LocalStorageService} from 'ngx-webstorage'
@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    LoginComponent,
    SignupComponent,
    UserComponent,
    FriendsComponent,
    MyfriendsComponent,
    FriendprofileComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    NgxWebstorageModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'welcome', component: WelcomeComponent },
      { path: '', redirectTo: 'welcome', pathMatch: 'full'},
      { path: 'login', component: LoginComponent },  
      { path: 'signup', component: SignupComponent },
      { path: 'user/:id', component: UserComponent },
      { path: 'friends/:id', component: FriendsComponent },
      { path: 'myfriends/:id', component: MyfriendsComponent},
      { path: 'friendprofile/:id1', component: FriendprofileComponent}
      
    ])
  ],
  providers: [CapbookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
