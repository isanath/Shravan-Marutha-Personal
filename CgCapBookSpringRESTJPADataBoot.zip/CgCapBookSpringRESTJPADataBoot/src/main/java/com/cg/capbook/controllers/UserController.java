package com.cg.capbook.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capbook.beans.Person;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.UserServices;

@RestController
@CrossOrigin
public class UserController {
@Autowired
UserServices userServices;

@RequestMapping(value="/SignUp",method=RequestMethod.POST,
consumes=MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<Person> acceptUserDetails(@RequestBody Person user){
	userServices.signUp(user);
return new ResponseEntity<>(user,HttpStatus.OK);
}

@RequestMapping(value="/Login",method=RequestMethod.POST,
consumes=MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<String> acceptProductDetails(@RequestParam String emailId,@RequestParam String password){
	try {
		userServices.SignIn(emailId, password);
		return new ResponseEntity<>("User details are found",HttpStatus.OK);
	} catch (UserDetailsNotFoundException e) {
		return new ResponseEntity<>("User details not found",HttpStatus.OK);
	}

}
}
