package com.cg.capbook.beans;

import java.util.List;

import javax.persistence.ManyToOne;

public class Album {
private List<String> Photos;

}
